package com.loan.exceptions;

public class MailException extends RuntimeException{

	public MailException(String message) {
		super(message);
	}

}
