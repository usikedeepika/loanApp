package com.loan.services;

public interface iMailService {

	public void sendMail(String email);

}
